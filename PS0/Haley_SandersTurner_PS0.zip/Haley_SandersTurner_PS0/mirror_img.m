function mirrored_img = mirror_img(img)
    
    mirrored_img = img(end:-1:1,:,:);
    
end