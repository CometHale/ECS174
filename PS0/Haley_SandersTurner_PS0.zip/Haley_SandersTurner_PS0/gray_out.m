function grayed_img = gray_out(img)
    grayed_img = rgb2gray(img);
end
  